#!/usr/bin/env bash
# Mezcla la canción de fondo con el video del tutorial (que ya trae los efectos).
# Uso: ./mezclar_musica.sh tutorial_sin_musica.mp4 salida.mp4
# Parámetros acordados con el cliente: Starman desde 0:35, música -11 dB, efectos +6 dB,
# fade-in 1 s, fade-out 3 s al final. Video = 96 s.
set -e
IN="${1:-tutorial_sin_musica.mp4}"; OUT="${2:-tutorial_con_musica.mp4}"
DIR="$(cd "$(dirname "$0")" && pwd)"
DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$IN")
FO=$(python3 -c "print(round($DUR-3,2))")
ffmpeg -y -v error -i "$IN" -ss 35 -t "$DUR" -i "$DIR/musica/Starman.mp3" -filter_complex \
 "[0:a]volume=6dB[s];[1:a]aresample=44100,volume=-11dB,afade=t=in:st=0:d=1,afade=t=out:st=$FO:d=3[m];[s][m]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95[a]" \
 -map 0:v -map "[a]" -c:v copy -c:a aac -b:a 192k -movflags +faststart "$OUT"
echo "Listo: $OUT"
