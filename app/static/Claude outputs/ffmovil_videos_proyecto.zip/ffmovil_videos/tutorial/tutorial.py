import math, subprocess, sys, wave, os
from pathlib import Path
BASE = Path(__file__).resolve().parent
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H, FPS = 1080, 1920, 30
SR = 44100
SH = str(BASE / "assets") + "/"
FD = os.environ.get("INTER_DIR", str(BASE.parent / "fonts")) + "/"
def F(w, s): return ImageFont.truetype(FD + f"Inter-{w}.otf", s)

BG1, BG2 = (9, 14, 28), (20, 32, 62)
ACC = (47, 109, 246); CYAN = (56, 189, 248); GOLD = (255, 194, 58)
WHITE = (255, 255, 255); MUTED = (170, 184, 210)

# ---------- sound event registry ----------
EVENTS = []; SEEN = set(); REC = True; ABS = 0.0; CUR_T = 0.0; SCN = 0
def ev(kind, key):
    k = (SCN,) + tuple(key)
    if REC and k not in SEEN:
        SEEN.add(k); EVENTS.append((ABS + CUR_T, kind))

# ---------- helpers ----------
def clamp(x, a=0, b=1): return max(a, min(b, x))
def ease(x): x = clamp(x); return x * x * (3 - 2 * x)
def eout(x): x = clamp(x); return 1 - (1 - x) ** 3
def eback(x):
    x = clamp(x); c1 = 1.70158; c3 = c1 + 1
    return 1 + c3 * (x - 1) ** 3 + c1 * (x - 1) ** 2

def make_bg():
    bg = Image.new("RGB", (W, H)); d = ImageDraw.Draw(bg)
    for y in range(H):
        t = y / H; k = (1 - abs(t - .45) * 1.6) if abs(t - .45) < .62 else 0
        d.line([(0, y), (W, y)], fill=tuple(int(BG1[i] + (BG2[i] - BG1[i]) * k) for i in range(3)))
    glow = Image.new("L", (W, H), 0)
    ImageDraw.Draw(glow).ellipse([W*.05, H*.18, W*.95, H*.62], fill=110)
    glow = glow.filter(ImageFilter.GaussianBlur(160))
    return Image.composite(Image.new("RGB", (W, H), (30, 70, 160)), bg, glow)
BG = make_bg()

def wrap(text, font, maxw):
    words, lines, cur = text.split(), [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if font.getlength(t) <= maxw: cur = t
        else: lines.append(cur); cur = w
    lines.append(cur); return lines

def text_block(lines_spec, maxw=960):
    rows = []
    for text, font, color, gap in lines_spec:
        wl = wrap(text, font, maxw)
        for i, ln in enumerate(wl):
            rows.append((ln, font, color, gap if i == len(wl) - 1 else 4))
    hgt = sum(f.size * 1.18 + g for _, f, _, g in rows)
    img = Image.new("RGBA", (W, int(hgt) + 12), (0, 0, 0, 0))
    d = ImageDraw.Draw(img); y = 0
    for ln, f, c, g in rows:
        x = (W - f.getlength(ln)) / 2
        d.text((x + 3, y + 4), ln, font=f, fill=(0, 0, 0, 140))
        d.text((x, y), ln, font=f, fill=c)
        y += f.size * 1.18 + g
    return img

def pill(text, font=None, fill=ACC):
    font = font or F("ExtraBold", 36)
    tw = font.getlength(text); w, h = int(tw + 60), 64
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img); d.rounded_rectangle([0, 0, w - 1, h - 1], 32, fill=fill)
    d.text((w / 2, h / 2), text, font=font, fill=WHITE, anchor="mm")
    return img

def paste_a(dst, src, xy, alpha=1.0):
    if alpha <= 0: return
    if alpha < 1:
        src = src.copy(); a = src.getchannel("A").point(lambda v: int(v * alpha)); src.putalpha(a)
    dst.alpha_composite(src, (int(xy[0]), int(xy[1])))

def scaled(img, s):
    return img.resize((max(1, int(img.width * s)), max(1, int(img.height * s))), Image.LANCZOS)

# ---------- phone (bigger, higher) ----------
S = 1.95
SW, SHh = int(375 * S), int(764 * S)
BEZ = 16
PX = (W - SW) // 2
PY = H - SHh - BEZ - 38
CAP_TOP, CAP_BOT = 18, PY - BEZ - 14

def load_screen(name, crop=764):
    im = Image.open(SH + name).convert("RGB")
    if im.width != 375:
        nh = int(im.height * 375 / im.width); im = im.resize((375, nh), Image.LANCZOS)
    im = im.crop((0, 0, 375, min(crop, im.height)))
    if im.height < 764:
        bgc = (17, 22, 31) if name.startswith("d37") else im.getpixel((4, im.height - 4))
        c = Image.new("RGB", (375, 764), bgc); c.paste(im, (0, 0)); im = c
    return im.resize((SW, SHh), Image.LANCZOS)

phone_mask = Image.new("L", (SW, SHh), 0)
ImageDraw.Draw(phone_mask).rounded_rectangle([0, 0, SW - 1, SHh - 1], 44, fill=255)
phone_frame = Image.new("RGBA", (W, H), (0, 0, 0, 0))
sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
ImageDraw.Draw(sh).rounded_rectangle([PX - BEZ + 10, PY - BEZ + 30, PX + SW + BEZ + 10, PY + SHh + BEZ + 30], 64, fill=(0, 0, 0, 150))
sh = sh.filter(ImageFilter.GaussianBlur(30))
ImageDraw.Draw(phone_frame).rounded_rectangle([PX - BEZ, PY - BEZ, PX + SW + BEZ, PY + SHh + BEZ], 60, fill=(14, 16, 22), outline=(70, 80, 105), width=3)
PHONE_BASE = BG.copy().convert("RGBA"); PHONE_BASE.alpha_composite(sh); PHONE_BASE.alpha_composite(phone_frame)

def screen_to_abs(x, y): return PX + x * S, PY + y * S
def put_screen(fr, scr): fr.paste(scr, (PX, PY), phone_mask)

def tap(fr, x, y, p):
    if p <= 0 or p >= 1: return
    ev("click", ("tap", round(x), round(y)))
    ax, ay = screen_to_abs(x, y)
    ov = Image.new("RGBA", fr.size, (0, 0, 0, 0)); d = ImageDraw.Draw(ov)
    r = 30 + 70 * eout(p); a = int(200 * (1 - p))
    d.ellipse([ax - r, ay - r, ax + r, ay + r], outline=(255, 255, 255, a), width=6)
    r2 = 30 * (1 - 0.3 * math.sin(p * math.pi)); a2 = int(230 * min(1, (1 - p) * 2.5))
    d.ellipse([ax - r2, ay - r2, ax + r2, ay + r2], fill=(255, 255, 255, a2 // 2), outline=(255, 255, 255, a2), width=4)
    fr.alpha_composite(ov)

def highlight(fr, box, t, color=GOLD):
    if t <= 0: return
    x0, y0 = screen_to_abs(box[0], box[1]); x1, y1 = screen_to_abs(box[2], box[3])
    a = int(255 * clamp(t * 3)); pulse = 4 + 3 * math.sin(t * 9)
    ov = Image.new("RGBA", fr.size, (0, 0, 0, 0)); d = ImageDraw.Draw(ov)
    d.rounded_rectangle([x0 - pulse, y0 - pulse, x1 + pulse, y1 + pulse], 22, outline=color + (a,), width=7)
    fr.alpha_composite(ov)

def type_text(fr, x, y, text, size=16, color=(235, 238, 245), cursor=True, t=0):
    if len(text) > 0: ev("key", ("type", round(x), round(y), len(text)))
    ax, ay = screen_to_abs(x, y)
    f = ImageFont.truetype(FD + "Inter-Regular.otf", int(size * S))
    d = ImageDraw.Draw(fr)
    d.text((ax, ay), text, font=f, fill=color, anchor="lm")
    if cursor and int(t * 2.2) % 2 == 0:
        cx = ax + f.getlength(text) + 3
        d.line([(cx, ay - size * S * .6), (cx, ay + size * S * .6)], fill=color, width=3)

def caption(fr, img, t):
    p = eout(t / 0.45)
    y = max(CAP_TOP, (CAP_TOP + CAP_BOT - img.height) / 2)
    paste_a(fr, img, (0, y - 40 * (1 - p)), p)

# ---------- assets ----------
LOGO = Image.open(SH + "c88ed701-image.png").convert("RGBA")
CHAR = Image.open(SH + "char_key.png").convert("RGBA")
LOGO_L = scaled(LOGO, 1.9); CHAR_L = scaled(CHAR, 3.35); LOGO_M = scaled(LOGO, 1.35)

scr = {n: load_screen(n) for n in ["04_login.png", "05_dash.png", "06_menu.png", "07_recargar.png",
        "09_verif.png", "10_paquete.png", "11_proc.png", "12_exito.png", "13_hist.png", "15_fondos.png", "h0.jpg"]}
scr["pwd"] = load_screen("d37ac0cc-image.png", crop=655)

long = Image.new("RGB", (375, 2253 + 812))
long.paste(Image.open(SH + "h0.jpg").convert("RGB"), (0, 0))
for k in (1, 2, 3):
    long.paste(Image.open(SH + f"h{k}.jpg").convert("RGB").crop((0, 61, 375, 812)), (0, 751 * k + 61))
LONG = long.resize((SW, int(long.height * S)), Image.LANCZOS)
HEADER = Image.open(SH + "h0.jpg").convert("RGB").crop((0, 0, 375, 61)).resize((SW, int(61 * S)), Image.LANCZOS)

def cap(title, sub=None, step=None):
    spec = [(title, F("ExtraBold", 62), WHITE, 14)]
    if sub: spec.append((sub, F("Medium", 38), MUTED, 0))
    img = text_block(spec, 980)
    if step:
        p = pill(step); out = Image.new("RGBA", (W, img.height + 80), (0, 0, 0, 0))
        out.alpha_composite(p, ((W - p.width) // 2, 0)); out.alpha_composite(img, (0, 80)); return out
    return img

# ---------- scenes ----------
scenes = []
def scene(dur):
    def deco(fn): scenes.append((dur, fn)); return fn
    return deco

def hero(t, block, logo_y=110, text_y=520, char_y=820):
    fr = BG.copy().convert("RGBA")
    p = eback(t / 0.7); lg = scaled(LOGO_L, max(0.01, p))
    paste_a(fr, lg, ((W - lg.width) / 2, logo_y + (LOGO_L.height - lg.height) / 2), clamp(t / 0.3))
    pt = eout((t - 0.4) / 0.6); paste_a(fr, block, (0, text_y + 50 * (1 - pt)), pt)
    pc = eout((t - 0.7) / 0.8); bob = 14 * math.sin(t * 2.2)
    paste_a(fr, CHAR_L, ((W - CHAR_L.width) / 2 + 40, char_y + bob + 70 * (1 - pc)), pc)
    return fr

C1 = text_block([("Te enseñaremos a usar", F("ExtraBold", 76), WHITE, 4),
                 ("nuestra plataforma", F("ExtraBold", 76), CYAN, 22),
                 ("Guía rápida · FFMovil", F("SemiBold", 42), MUTED, 0)])
@scene(5.5)
def s_intro(t): return hero(t, C1)

C2 = cap("Ingresa desde tu navegador", "Escribe la dirección en la barra de tu navegador")
URL = "ffmovil.com"
H0_small = Image.open(SH + "h0.jpg").convert("RGB")
@scene(5.5)
def s_browser(t):
    fr = BG.copy().convert("RGBA"); caption(fr, C2, t)
    bx, by, bw, bh = 70, PY - BEZ, 940, H - (PY - BEZ) - 40
    pin = eout(t / 0.5); oy = 80 * (1 - pin)
    win = Image.new("RGBA", (bw, bh), (0, 0, 0, 0)); d = ImageDraw.Draw(win)
    d.rounded_rectangle([0, 0, bw - 1, bh - 1], 40, fill=(26, 31, 44), outline=(70, 80, 105), width=3)
    d.rounded_rectangle([0, 0, bw - 1, 200], 40, fill=(36, 42, 58)); d.rectangle([0, 160, bw - 1, 200], fill=(36, 42, 58))
    for i, c in enumerate([(255, 95, 87), (255, 189, 46), (40, 200, 64)]):
        d.ellipse([36 + i * 44, 34, 64 + i * 44, 62], fill=c)
    d.rounded_rectangle([30, 92, bw - 30, 176], 42, fill=(16, 19, 28), outline=CYAN if 0.6 < t < 3.6 else (60, 70, 90), width=4)
    d.rounded_rectangle([66, 128, 94, 152], 5, fill=(140, 200, 140)); d.arc([70, 112, 90, 136], 180, 360, fill=(140, 200, 140), width=5)
    n = int(clamp((t - 0.8) / 1.8) * len(URL) + 0.0001)
    if n > 0: ev("key", ("url", n))
    if 0.55 < t: ev("click", ("urlbar",))
    typed = URL[:n]; f = F("SemiBold", 48)
    if n == 0 and t < 0.8:
        d.text((120, 134), "Buscar o escribir dirección", font=F("Regular", 40), fill=(110, 120, 140), anchor="lm")
    else:
        d.text((120, 134), typed, font=f, fill=WHITE, anchor="lm")
        if t < 3.4 and int(t * 2.4) % 2 == 0:
            cx = 120 + f.getlength(typed) + 4; d.line([(cx, 108), (cx, 160)], fill=WHITE, width=4)
    if 2.8 < t < 3.6:
        ev("click", ("enter",))
        k = eback((t - 2.8) / 0.3)
        kw = Image.new("RGBA", (180, 76), (0, 0, 0, 0)); kd = ImageDraw.Draw(kw)
        kd.rounded_rectangle([0, 0, 179, 75], 18, fill=ACC); kd.text((90, 38), "Ir  ⏎", font=F("Bold", 36), fill=WHITE, anchor="mm")
        kw = scaled(kw, max(0.05, k)); win.alpha_composite(kw, (bw - 40 - kw.width, 102 + (76 - kw.height) // 2 - 4))
    if t > 3.4:
        pr = clamp((t - 3.4) / 0.9); d.rectangle([0, 200, int(bw * pr), 208], fill=ACC)
    if t > 3.9:
        a = clamp((t - 3.9) / 0.6)
        cont = H0_small.resize((bw - 6, int(H0_small.height * (bw - 6) / 375)), Image.LANCZOS).crop((0, 0, bw - 6, bh - 212))
        cm = Image.new("L", cont.size, 0); ImageDraw.Draw(cm).rounded_rectangle([0, -40, cont.width - 1, cont.height - 1], 38, fill=int(255 * a))
        win.paste(cont, (3, 209), cm)
    paste_a(fr, win, (bx, by + oy), pin)
    return fr

C3 = cap("Esta es nuestra página de inicio", "Desliza para conocer cómo funciona")
@scene(6.5)
def s_home(t):
    fr = PHONE_BASE.copy(); caption(fr, C3, t)
    if t >= 0.8: ev("swipe", ("s1",))
    if t >= 3.0: ev("swipe", ("s2",))
    s = ease((t - 0.8) / 4.6) * 2253 * S
    view = LONG.crop((0, int(s), SW, int(s) + SHh)); view.paste(HEADER, (0, 0))
    put_screen(fr, view)
    return fr

C4 = cap("Toca «Iniciar sesión»", "Arriba a la derecha de la página de inicio")
C5 = cap("Escribe tu usuario y contraseña", "Te los entrega nuestro soporte")
@scene(3.0)
def s_tap_login(t):
    fr = PHONE_BASE.copy(); caption(fr, C4, t)
    a = clamp((t - 2.0) / 0.5)
    put_screen(fr, Image.blend(scr["h0.jpg"], scr["04_login.png"], a))
    if t < 2.0: highlight(fr, (227, 8, 359, 52), (t - 0.4) / 1.6)
    tap(fr, 293, 29, (t - 1.3) / 0.7)
    return fr

@scene(8.0)
def s_login(t):
    fr = PHONE_BASE.copy(); caption(fr, C5, t)
    put_screen(fr, scr["04_login.png"])
    tap(fr, 120, 395, (t - 0.3) / 0.6)
    u = "bowie"; nu = int(clamp((t - 0.7) / 1.3) * len(u) + 1e-4)
    if t > 0.6: type_text(fr, 48, 395, u[:nu], cursor=t < 2.4, t=t)
    tap(fr, 120, 491, (t - 2.4) / 0.6)
    pw = "bowie123"; npw = int(clamp((t - 2.8) / 1.8) * len(pw) + 1e-4)
    reveal = t > 5.1
    if t > 2.7:
        txt = pw[:npw] if reveal else "•" * npw
        type_text(fr, 48, 491, txt, cursor=2.7 < t < 6.0, t=t)
    tap(fr, 321, 491, (t - 4.8) / 0.6)
    if reveal:
        p = eout((t - 5.1) / 0.4)
        lab = pill("usuario: bowie   ·   contraseña: bowie123", F("Bold", 32), (20, 120, 80))
        paste_a(fr, lab, ((W - lab.width) / 2, PY + 640 * S + 40 * (1 - p)), p)
    tap(fr, 187, 557, (t - 6.6) / 0.7)
    if 6.4 < t: highlight(fr, (32, 532, 343, 582), (t - 6.4) / 1.5, CYAN)
    return fr

@scene(5.0)
def s_first(t):
    fr = BG.copy().convert("RGBA")
    p = eback(t / 0.6)
    cw, ch = 960, 1000
    card = Image.new("RGBA", (cw, ch), (0, 0, 0, 0)); d = ImageDraw.Draw(card)
    d.rounded_rectangle([0, 0, cw - 1, ch - 1], 48, fill=(24, 30, 46), outline=GOLD, width=5)
    d.ellipse([cw/2 - 100, 70, cw/2 + 100, 270], fill=GOLD); d.text((cw/2, 172), "!", font=F("Black", 140), fill=(24, 30, 46), anchor="mm")
    d.text((cw/2, 360), "¿Primera vez?", font=F("ExtraBold", 80), fill=WHITE, anchor="mm")
    y = 470
    for ln in wrap("Si es la primera vez que inicias sesión, escribe correctamente tu usuario y tu contraseña temporal.", F("Medium", 50), 840):
        d.text((cw/2, y), ln, font=F("Medium", 50), fill=MUTED, anchor="mm"); y += 68
    y += 40
    for ln in wrap("Respeta mayúsculas, minúsculas y números.", F("SemiBold", 46), 840):
        d.text((cw/2, y), ln, font=F("SemiBold", 46), fill=GOLD, anchor="mm"); y += 62
    c = scaled(card, max(0.05, p))
    paste_a(fr, c, ((W - c.width) / 2, 640 + (ch - c.height) / 2), clamp(t / 0.3))
    paste_a(fr, LOGO_M, ((W - LOGO_M.width) / 2, 200), clamp(t / 0.5))
    return fr

C6 = cap("Crea una contraseña segura", "Mínimo 8 caracteres, combina letras y números. ¡No la olvides!")
@scene(6.0)
def s_pwd(t):
    fr = PHONE_BASE.copy(); caption(fr, C6, t)
    put_screen(fr, scr["pwd"])
    k = 375 / 394
    highlight(fr, (32 * k, 285 * k, 362 * k, 336 * k), (t - 0.9) / 2.0)
    highlight(fr, (32 * k, 385 * k, 362 * k, 437 * k), (t - 2.2) / 2.0, CYAN)
    tap(fr, 197 * k, 501 * k, (t - 4.6) / 0.7)
    return fr

C7 = cap("¡Ya estás dentro!", "En tu panel ves tu saldo, tu gasto y tus recargas")
@scene(4.5)
def s_dash(t):
    fr = PHONE_BASE.copy(); caption(fr, C7, t)
    put_screen(fr, scr["05_dash.png"])
    highlight(fr, (16, 178, 182, 286), (t - 0.9) / 1.6)
    if t > 2.4: highlight(fr, (16, 430, 359, 480), (t - 2.4) / 1.8, CYAN)
    return fr

C8 = cap("El botón «Menú»", "Inicio · Recargar · Historial · Fondos · Salir")
MENU_ITEMS = [(168, 86, 358, 130), (168, 130, 358, 174), (168, 174, 358, 218), (168, 218, 358, 262), (184, 268, 342, 312)]
@scene(5.5)
def s_menu(t):
    fr = PHONE_BASE.copy(); caption(fr, C8, t)
    a = clamp((t - 1.2) / 0.3)
    put_screen(fr, Image.blend(scr["05_dash.png"], scr["06_menu.png"], a))
    tap(fr, 318, 52, (t - 0.6) / 0.7)
    i = int((t - 1.7) / 0.7)
    if 0 <= i < len(MENU_ITEMS): highlight(fr, MENU_ITEMS[i], ((t - 1.7) % 0.7) / 0.7 + 0.4, CYAN)
    return fr

C8b = cap("Abona saldo a tu cuenta", "Una vez dentro, contacta a nuestro soporte para que recargue tu saldo. Sin saldo no puedes recargar diamantes.", step="ANTES DE RECARGAR")
@scene(7.0)
def s_saldo(t):
    fr = PHONE_BASE.copy(); caption(fr, C8b, t)
    a = clamp((t - 1.3) / 0.4)
    put_screen(fr, Image.blend(scr["06_menu.png"], scr["15_fondos.png"], a))
    if t < 1.3: highlight(fr, MENU_ITEMS[3], (t - 0.1) / 1.2, CYAN)
    tap(fr, 295, 240, (t - 0.7) / 0.6)
    if t > 1.9: highlight(fr, (16, 178, 182, 286), (t - 1.9) / 2.0)
    if t > 3.8: highlight(fr, (16, 366, 359, 512), (t - 3.8) / 2.0, CYAN)
    return fr

C9 = cap("Toca «Recargar»", "Abre el menú y elige «Recargar»", step="PASO 1")
@scene(4.5)
def s_rec(t):
    fr = PHONE_BASE.copy(); caption(fr, C9, t)
    if t < 1.0:
        put_screen(fr, Image.blend(scr["15_fondos.png"], scr["06_menu.png"], clamp((t - 0.7) / 0.3)))
    elif t < 2.7:
        put_screen(fr, scr["06_menu.png"])
    else:
        put_screen(fr, Image.blend(scr["06_menu.png"], scr["07_recargar.png"], clamp((t - 2.7) / 0.4)))
    tap(fr, 318, 52, (t - 0.25) / 0.6)
    if 1.1 < t < 2.7: highlight(fr, (168, 130, 358, 174), (t - 1.1) / 1.4, CYAN)
    tap(fr, 295, 152, (t - 2.0) / 0.7)
    return fr

C10 = cap("Escribe el Player ID", "Solo números · Luego toca «Verificar ID»", step="PASO 2")
@scene(5.0)
def s_id(t):
    fr = PHONE_BASE.copy(); caption(fr, C10, t)
    put_screen(fr, scr["07_recargar.png"])
    if t > 0.5:
        d = ImageDraw.Draw(fr); x0, y0 = screen_to_abs(18, 278); x1, y1 = screen_to_abs(357, 324)
        d.rounded_rectangle([x0, y0, x1, y1], 12, fill=(32, 36, 47))
        pid = "19470108"; n = int(clamp((t - 0.7) / 1.8) * len(pid) + 1e-4)
        type_text(fr, 33, 301, pid[:n], cursor=t < 3.2, t=t)
    tap(fr, 187, 301, (t - 0.2) / 0.6)
    if t < 3.3: highlight(fr, (16, 276, 359, 326), (t - 2.6) / 1.0, GOLD)
    tap(fr, 187, 373, (t - 3.6) / 0.7)
    if t > 3.4: highlight(fr, (16, 348, 359, 398), (t - 3.4) / 1.6, CYAN)
    return fr

C11 = cap("Verifica el nombre del jugador", "Asegúrate de que sea la cuenta correcta", step="PASO 3")
@scene(4.5)
def s_verif(t):
    fr = PHONE_BASE.copy(); caption(fr, C11, t)
    put_screen(fr, Image.blend(scr["07_recargar.png"], scr["09_verif.png"], clamp(t / 0.4)))
    highlight(fr, (16, 248, 359, 398), (t - 0.8) / 2.0)
    return fr

C12 = cap("Elige el paquete", "Ejemplo: 572 diamantes por 4.20 USD", step="PASO 4")
@scene(5.0)
def s_pack(t):
    fr = PHONE_BASE.copy(); caption(fr, C12, t)
    if t < 1.6:
        put_screen(fr, scr["09_verif.png"])
        highlight(fr, (32, 595, 166, 715), (t - 0.3) / 1.3, CYAN)
        tap(fr, 98, 655, (t - 0.9) / 0.7)
    else:
        if t >= 1.6: ev("swipe", ("p",))
        put_screen(fr, Image.blend(scr["09_verif.png"], scr["10_paquete.png"], ease((t - 1.6) / 0.6)))
        if t > 2.2: highlight(fr, (32, 166, 166, 286), (t - 2.2) / 2.0)
    return fr

C13 = cap("Revisa y confirma", "La recarga es irreversible: revisa el ID y el jugador", step="PASO 5")
@scene(6.0)
def s_conf(t):
    fr = PHONE_BASE.copy(); caption(fr, C13, t)
    if t < 3.6:
        put_screen(fr, scr["10_paquete.png"])
        highlight(fr, (24, 380, 351, 520), (t - 0.6) / 1.6)
        if t > 2.0: highlight(fr, (32, 534, 343, 632), (t - 2.0) / 1.2, (255, 120, 80))
        tap(fr, 187, 674, (t - 3.0) / 0.6)
        if t > 2.8: highlight(fr, (32, 649, 343, 699), (t - 2.8) / 1.0, CYAN)
    else:
        put_screen(fr, scr["11_proc.png"])
        highlight(fr, (32, 649, 343, 699), (t - 3.6) / 2.4, CYAN)
    return fr

C14 = cap("¡Recarga exitosa!", "Recibes el número de pedido y todos los detalles")
@scene(4.5)
def s_ok(t):
    fr = PHONE_BASE.copy(); caption(fr, C14, t)
    if t >= 0.1: ev("success", ("ok",))
    put_screen(fr, Image.blend(scr["11_proc.png"], scr["12_exito.png"], clamp(t / 0.35)))
    highlight(fr, (32, 240, 102, 268), (t - 0.6) / 1.4, (60, 200, 140))
    if t > 2.0: highlight(fr, (16, 178, 359, 584), (t - 2.0) / 2.5, CYAN)
    return fr

C15 = cap("Historial", "Lleva el control de todas tus recargas")
@scene(5.0)
def s_hist(t):
    fr = PHONE_BASE.copy(); caption(fr, C15, t)
    put_screen(fr, Image.blend(scr["12_exito.png"], scr["13_hist.png"], clamp((t - 1.3) / 0.4)))
    if t < 1.3: highlight(fr, (183, 504, 280, 554), (t - 0.2) / 1.1, CYAN)
    tap(fr, 231, 529, (t - 0.7) / 0.6)
    if t > 1.9: highlight(fr, (16, 244, 359, 540), (t - 1.9) / 2.5)
    if t > 3.2: highlight(fr, (16, 178, 359, 228), (t - 3.2) / 1.6, CYAN)
    return fr

C17 = text_block([("¡Listo! Ya sabes recargar", F("ExtraBold", 72), WHITE, 6),
                  ("con FFMovil", F("ExtraBold", 72), CYAN, 24),
                  ("ffmovil.com", F("Bold", 56), GOLD, 0)])
@scene(5.0)
def s_outro(t): return hero(t, C17)

# ---------- sounds ----------
rng = np.random.default_rng(7)
def env_exp(n, tau): return np.exp(-np.arange(n) / (tau * SR))
def snd_click(vol=0.22):
    n = int(0.045 * SR); tt = np.arange(n) / SR
    noise = np.diff(rng.standard_normal(n + 1)) * env_exp(n, 0.0025)
    tone = np.sin(2 * np.pi * 1900 * tt) * env_exp(n, 0.006) * 0.6
    thump = np.sin(2 * np.pi * 220 * tt) * env_exp(n, 0.012) * 0.5
    s = noise * 0.35 + tone + thump
    return vol * s / np.abs(s).max()
def snd_key():
    n = int(0.035 * SR); tt = np.arange(n) / SR; f = rng.uniform(2300, 3300)
    noise = np.diff(rng.standard_normal(n + 1)) * env_exp(n, 0.0015)
    tone = np.sin(2 * np.pi * f * tt) * env_exp(n, 0.003) * 0.5
    thock = np.sin(2 * np.pi * rng.uniform(150, 190) * tt) * env_exp(n, 0.008) * 0.6
    s = noise * 0.5 + tone + thock
    return rng.uniform(0.09, 0.13) * s / np.abs(s).max()
def bandnoise(n, lo, hi):
    X = np.fft.rfft(rng.standard_normal(n)); fr = np.fft.rfftfreq(n, 1 / SR)
    X[(fr < lo) | (fr > hi)] = 0; x = np.fft.irfft(X, n); return x / np.abs(x).max()
def snd_whoosh(dur=0.42, vol=0.10):
    n = int(dur * SR); x = np.linspace(0, 1, n)
    lo = bandnoise(n, 150, 900); hi = bandnoise(n, 900, 4500)
    mix = lo * (1 - x) + hi * x * 0.6
    e = np.sin(np.pi * x) ** 2
    return vol * mix * e
def snd_success():
    n = int(1.1 * SR); out = np.zeros(n)
    for i, f in enumerate([1046.5, 1318.5, 1568.0, 2093.0]):
        st = int(i * 0.085 * SR); m = n - st; tt = np.arange(m) / SR
        tone = (np.sin(2 * np.pi * f * tt) + 0.25 * np.sin(2 * np.pi * 2 * f * tt)) * env_exp(m, 0.28)
        tone[: int(0.004 * SR)] *= np.linspace(0, 1, int(0.004 * SR))
        out[st:] += tone * (0.8 if i < 3 else 0.5)
    return 0.16 * out / np.abs(out).max()

def build_audio(total, path):
    buf = np.zeros(int((total + 1.5) * SR))
    def add(s, t):
        i = int(t * SR); j = min(len(buf), i + len(s)); buf[i:j] += s[: j - i]
    for t, k in EVENTS:
        if k == "click": add(snd_click(), t)
        elif k == "key": add(snd_key(), t)
        elif k == "swipe": add(snd_whoosh(0.6, 0.08), t)
        elif k == "whoosh": add(snd_whoosh(0.42, 0.10), t)
        elif k == "success": add(snd_success(), t)
    buf = buf[: int(total * SR)]
    pk = np.abs(buf).max()
    if pk > 0.9: buf *= 0.9 / pk
    st = (np.stack([buf, buf], 1) * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(st.tobytes())

# ---------- render ----------
XF = 0.35
out = sys.argv[1] if len(sys.argv) > 1 else str(BASE / "tutorial_sin_musica.mp4")
if "--preview" in sys.argv:
    os.makedirs(BASE / "preview", exist_ok=True)
    for i, (dur, fn) in enumerate(scenes):
        for frac in (0.5, 0.85):
            fn(dur * frac).convert("RGB").save(str(BASE / "preview") + f"/s{i:02d}_{int(frac*100)}.jpg", quality=85)
    sys.exit()

total = sum(d for d, _ in scenes)
tmpv = str(BASE / "_tmp_video.mp4")
ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                       "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", tmpv], stdin=subprocess.PIPE)
for i, (dur, fn) in enumerate(scenes):
    SCN = i; n = int(round(dur * FPS)); wh = False
    for f in range(n):
        t = f / FPS; CUR_T = t; REC = True
        img = fn(t).convert("RGB")
        if i + 1 < len(scenes) and t > dur - XF:
            if not wh: EVENTS.append((ABS + t - 0.08, "whoosh")); wh = True
            REC = False
            nxt = scenes[i + 1][1](0).convert("RGB")
            REC = True
            img = Image.blend(img, nxt, (t - (dur - XF)) / XF)
        ff.stdin.write(img.tobytes())
    ABS += n / FPS
    print("scene", i, file=sys.stderr)
ff.stdin.close(); ff.wait()
build_audio(ABS, str(BASE / "_tmp_audio.wav"))
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmpv, "-i", str(BASE / "_tmp_audio.wav"), "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                "-shortest", "-movflags", "+faststart", out], check=True)
print("events", len(EVENTS), "dur", ABS, file=sys.stderr)
