import math, subprocess, sys, wave, random, os
from pathlib import Path
BASE = Path(__file__).resolve().parent
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H, FPS, SR = 1080, 1920, 30, 44100
IMG = str(BASE / "assets/web") + "/"; IMG2 = str(BASE / "assets/extra") + "/"; SCR = str(BASE / "assets/capturas") + "/"
FD = os.environ.get("INTER_DIR", str(BASE.parent / "fonts")) + "/"  # carpeta con Inter-*.otf e InterDisplay-*.otf
SONG = str(BASE / "musica/Killer_Queen.mp3")
SONG_START = 84.5
def FDp(w, s): return ImageFont.truetype(FD + f"InterDisplay-{w}.otf", s)
def F(w, s): return ImageFont.truetype(FD + f"Inter-{w}.otf", s)
ACC = (47, 109, 246); CYAN = (64, 196, 255); GOLD = (255, 196, 64); WHITE = (255, 255, 255); MUTED = (190, 202, 225)
GREEN = (37, 190, 100)

BEATS = [float(b) for b in np.load(BASE / "beats.npy")]
B = lambda i: BEATS[i]
BOUNDS = [0.0, B(4), B(8), B(12), B(16), B(20), B(24), B(28), B(36), B(40), B(44), B(52)]
TOTAL = BOUNDS[-1] + 0.6

def clamp(x, a=0, b=1): return max(a, min(b, x))
def ease(x): x = clamp(x); return x * x * (3 - 2 * x)
def eout(x): x = clamp(x); return 1 - (1 - x) ** 3
def eback(x):
    x = clamp(x); c1 = 1.5; c3 = c1 + 1
    return 1 + c3 * (x - 1) ** 3 + c1 * (x - 1) ** 2
def scaled(img, s): return img.resize((max(1, round(img.width * s)), max(1, round(img.height * s))), Image.LANCZOS)
def fit_w(img, w): return scaled(img, w / img.width)
def paste_a(dst, src, xy, alpha=1.0):
    if alpha <= 0.003: return
    if alpha < 0.999:
        src = src.copy(); src.putalpha(src.getchannel("A").point(lambda v: int(v * alpha)))
    dst.alpha_composite(src, (int(round(xy[0])), int(round(xy[1]))))
def paste_c(dst, src, cx, cy, s=1.0, alpha=1.0):
    im = src if abs(s - 1) < 1e-3 else scaled(src, max(0.02, s))
    paste_a(dst, im, (cx - im.width / 2, cy - im.height / 2), alpha)
def sharpen(im): return im.filter(ImageFilter.UnsharpMask(radius=1.2, percent=60, threshold=2))

# ---------- assets ----------
def load(p): return Image.open(p).convert("RGBA")
def trim(im):
    bb = im.getchannel("A").point(lambda v: 255 if v > 12 else 0).getbbox(); return im.crop(bb)
LOGO = load(IMG + "logo.png"); FFW = load(IMG + "inicio/freefire-blanco.webp")
DIAMS = trim(load(IMG2 + "diamantes.png")); MALETIN = trim(load(IMG2 + "maletin.png"))
COFRE = trim(load(IMG + "inicio/cofre.webp"))
P2 = load(IMG + "inicio/personaje-2.webp")
PJ_MASK = trim(load(IMG2 + "pj_mask.png")); PJ_HOLO = trim(load(IMG2 + "pj_holo.png")); PJ_YEL = trim(load(IMG2 + "pj_yellow.png"))
M4 = trim(load(IMG2 + "m4.png")); P90 = trim(load(IMG2 + "p90.png"))
WA = trim(load(IMG2 + "whatsapp.png"))

def fade_bottom(im, frac=0.18):
    a = np.asarray(im.getchannel("A")).astype(float); h = a.shape[0]; n = int(h * frac)
    ramp = np.ones(h); ramp[h - n:] = np.linspace(1, 0, n) ** 1.5
    im = im.copy(); im.putalpha(Image.fromarray((a * ramp[:, None]).astype(np.uint8))); return im
PJ_YEL = fade_bottom(PJ_YEL, 0.16)

def glow_of(img, radius=30, color=(80, 160, 255), strength=1.0):
    a = img.getchannel("A").filter(ImageFilter.GaussianBlur(radius)).point(lambda v: int(min(255, v * 1.4 * strength)))
    g = Image.new("RGBA", img.size, color + (0,)); g.putalpha(a); return g
def with_glow(img, pad=60, radius=30, color=(80, 160, 255), strength=1.0):
    big = Image.new("RGBA", (img.width + 2 * pad, img.height + 2 * pad), (0, 0, 0, 0)); big.alpha_composite(img, (pad, pad))
    out = glow_of(big, radius, color, strength); out.alpha_composite(big); return out

LOGO_G = with_glow(sharpen(scaled(LOGO, 2.0)), 70, 36, (90, 170, 255), 1.0)          # 384px logo
DIAMS_BIG = with_glow(sharpen(fit_w(DIAMS, 760)), 90, 44, (80, 170, 255), 1.1)
DIAMS_HAND = with_glow(fit_w(DIAMS, 270), 40, 18, (80, 170, 255), 1.0)
DIAMS_STEP = with_glow(sharpen(fit_w(DIAMS, 640)), 70, 34, (80, 170, 255), 1.0)
MAL_STEP = with_glow(sharpen(fit_w(MALETIN, 720)), 70, 34, (90, 170, 255), 0.9)
COF_STEP = with_glow(sharpen(fit_w(COFRE, 720)), 70, 34, (255, 190, 80), 0.6)
FFW_S = fit_w(FFW, 520)
P2_L = sharpen(scaled(P2, 1.45))
PJ_MASK_L = sharpen(scaled(PJ_MASK, 1.55)); PJ_HOLO_L = sharpen(scaled(PJ_HOLO, 1.75)); PJ_YEL_L = sharpen(scaled(PJ_YEL, 1.75))
M4_L = sharpen(fit_w(M4, 640)); P90_L = sharpen(fit_w(P90, 500))
WA_L = sharpen(fit_w(WA, 300))
M4_X = with_glow(M4_L, 40, 20, (255, 90, 60), 0.7).rotate(28, expand=True, resample=Image.BICUBIC)
P90_X = with_glow(fit_w(P90, 560), 40, 20, (255, 90, 60), 0.7).rotate(-28, expand=True, resample=Image.BICUBIC)

# ---------- background ----------
def make_bg():
    y = np.linspace(0, 1, H)[:, None]; x = np.linspace(0, 1, W)[None, :]
    r = np.sqrt((x - .5) ** 2 * 1.6 + (y - .45) ** 2)
    base = np.array([7, 11, 24]); glow = np.array([26, 60, 140])
    k = np.clip(1 - r * 1.6, 0, 1) ** 1.6
    arr = base[None, None, :] + (glow - base)[None, None, :] * k[..., None]
    return Image.fromarray(arr.astype(np.uint8), "RGB").convert("RGBA")
BG = make_bg()
def make_rays():
    im = Image.new("L", (1700, 1700), 0); d = ImageDraw.Draw(im)
    for i in range(16):
        a0 = i * 360 / 16; d.pieslice([0, 0, 1700, 1700], a0, a0 + 8, fill=34)
    m = Image.new("L", im.size, 0); ImageDraw.Draw(m).ellipse([150, 150, 1550, 1550], fill=255); m = m.filter(ImageFilter.GaussianBlur(220))
    return Image.composite(im, Image.new("L", im.size, 0), m).filter(ImageFilter.GaussianBlur(12))
RAYS = make_rays()
random.seed(4)
BOKEH = [(random.uniform(0, W), random.uniform(0, H), random.uniform(3, 9), random.uniform(25, 80), random.uniform(0, 6)) for _ in range(34)]
def background(T, rays=0.0, cy=900, ray_color=(70, 140, 255)):
    fr = BG.copy()
    if rays > 0:
        r = RAYS.rotate(T * 10, resample=Image.BILINEAR)
        lay = Image.new("RGBA", r.size, ray_color + (0,)); lay.putalpha(r.point(lambda v: int(v * rays)))
        fr.alpha_composite(lay, ((W - 1700) // 2, cy - 850))
    ov = Image.new("RGBA", fr.size, (0, 0, 0, 0)); d = ImageDraw.Draw(ov)
    for (x, y, r, sp, ph) in BOKEH:
        yy = (y - T * sp) % (H + 40) - 20; a = int(60 + 45 * math.sin(T * 1.5 + ph))
        d.ellipse([x - r, yy - r, x + r, yy + r], fill=(140, 200, 255, a))
    fr.alpha_composite(ov.filter(ImageFilter.GaussianBlur(2)))
    return fr

# ---------- crisp text ----------
TXT_CACHE = {}
def text_line(txt, size, color=WHITE, weight="ExtraBold", display=True):
    key = (txt, size, color, weight, display)
    if key in TXT_CACHE: return TXT_CACHE[key]
    f = FDp(weight, size) if display else F(weight, size)
    l, t, r, b = f.getbbox(txt); w, h = r - l, b - t
    pad = 30
    im = Image.new("RGBA", (w + 2 * pad, h + 2 * pad), (0, 0, 0, 0))
    sh = Image.new("RGBA", im.size, (0, 0, 0, 0))
    ImageDraw.Draw(sh).text((pad - l, pad - t + 5), txt, font=f, fill=(0, 0, 0, 200))
    im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(8)))
    ImageDraw.Draw(im).text((pad - l, pad - t), txt, font=f, fill=color)
    TXT_CACHE[key] = im; return im
def show_text(fr, im, t, cy, delay=0.0, cx=W / 2, dy=40):
    p = eback((t - delay) / 0.38)
    if t - delay <= 0: return
    paste_a(fr, im, (cx - im.width / 2, cy - im.height / 2 + dy * (1 - p)), clamp((t - delay) / 0.2))

def pill(text, fill=ACC, size=40, fg=WHITE):
    f = FDp("ExtraBold", size); l, t_, r, b = f.getbbox(text)
    w = int(r - l + 72); h = int(size * 1.75)
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, w - 1, h - 1], h // 2, fill=fill); d.text((w / 2, h / 2), text, font=f, fill=fg, anchor="mm")
    return im

# ---------- phone ----------
PS = 1.45; SW, SHh = round(375 * PS), round(764 * PS); BEZ = 14; PAD = 40
FIELD = Image.open(SCR + "a_empty.png").convert("RGB").getpixel((300, 240))
def load_scr(n): return Image.open(SCR + n).convert("RGB").crop((0, 0, 375, 764)).resize((SW, SHh), Image.LANCZOS)
SCREENS = {k: load_scr(k + ".png") for k in ["a_empty", "c_verif", "d_sel", "e_ok", "f_hist"]}
PMASK = Image.new("L", (SW, SHh), 0); ImageDraw.Draw(PMASK).rounded_rectangle([0, 0, SW - 1, SHh - 1], 38, fill=255)
PHONE_W, PHONE_H = SW + 2 * BEZ + 2 * PAD, SHh + 2 * BEZ + 2 * PAD
def phone_img(screen):
    im = Image.new("RGBA", (PHONE_W, PHONE_H), (0, 0, 0, 0))
    sh = Image.new("RGBA", im.size, (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle([PAD, PAD + 16, PAD + SW + 2 * BEZ, PAD + 16 + SHh + 2 * BEZ], 52, fill=(0, 0, 0, 170))
    im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(20)))
    ImageDraw.Draw(im).rounded_rectangle([PAD, PAD, PAD + SW + 2 * BEZ, PAD + SHh + 2 * BEZ], 52, fill=(14, 16, 22), outline=(90, 110, 150), width=3)
    im.paste(screen, (PAD + BEZ, PAD + BEZ), PMASK)
    return im
PHONES = {k: phone_img(v) for k, v in SCREENS.items()}
def sxy(ox, oy, x, y, s=1.0): return ox + (PAD + BEZ + x * PS) * s, oy + (PAD + BEZ + y * PS) * s
def tap_at(fr, ax, ay, p):
    if p <= 0 or p >= 1: return
    ov = Image.new("RGBA", fr.size, (0, 0, 0, 0)); d = ImageDraw.Draw(ov)
    r = 24 + 56 * eout(p); a = int(210 * (1 - p))
    d.ellipse([ax - r, ay - r, ax + r, ay + r], outline=(255, 255, 255, a), width=5)
    r2 = 24; a2 = int(230 * min(1, (1 - p) * 2.5))
    d.ellipse([ax - r2, ay - r2, ax + r2, ay + r2], fill=(255, 255, 255, a2 // 2), outline=(255, 255, 255, a2), width=4)
    fr.alpha_composite(ov)

# ---------- scenes ----------
def sc_hook(t, T, d):
    fr = background(T, rays=1.0 * ease(t / 0.6), cy=1150)
    s = 0.55 + 0.45 * eout(t / 0.6)
    paste_c(fr, DIAMS_BIG, W / 2, 1180 + 16 * math.sin(t * 3), s, clamp(t / 0.25))
    show_text(fr, FFW_S, t, 330, 0.0)
    show_text(fr, text_line("¿Juegas", 128), t, 530, 0.2)
    show_text(fr, text_line("Free Fire?", 128, CYAN), t, 680, 0.35)
    return fr

def sc_biz(t, T, d):
    fr = background(T)
    left = 50 + 420 * (1 - eout(t / 0.5)); top = 640
    bob = 10 * math.sin(T * 2.4)
    paste_a(fr, P2_L, (left, top + bob), clamp(t / 0.25))
    # palm at (70,285) in P2 coords -> diamonds hover above palm
    hx = left + 75 * 1.45; hy = top + bob + 285 * 1.45 - DIAMS_HAND.height / 2 - 6 + 10 * math.sin(T * 4)
    paste_c(fr, DIAMS_HAND, hx + 20, hy, 1.0, clamp((t - 0.35) / 0.3))
    show_text(fr, text_line("Conviértelo en", 92), t, 300, 0.05)
    show_text(fr, text_line("tu negocio", 132, GOLD), t, 450, 0.3)
    return fr

def sc_logo(t, T, d):
    fr = background(T, rays=1.1, cy=760)
    if t < 0.8:
        ov = Image.new("RGBA", fr.size, (0, 0, 0, 0)); dd = ImageDraw.Draw(ov)
        r = 160 + 650 * eout(t / 0.8); a = int(180 * (1 - t / 0.8))
        dd.ellipse([W / 2 - r, 760 - r, W / 2 + r, 760 + r], outline=(140, 200, 255, a), width=8); fr.alpha_composite(ov)
    paste_c(fr, LOGO_G, W / 2, 760, max(0.05, eback(t / 0.45)), clamp(t / 0.15))
    show_text(fr, text_line("Vende diamantes", 96), t, 1180, 0.3)
    show_text(fr, text_line("a tus clientes", 96, CYAN), t, 1300, 0.45)
    show_text(fr, text_line("con nuestra plataforma", 50, MUTED, "SemiBold"), t, 1420, 0.65)
    return fr

def sc_easy(t, T, d):
    fr = background(T)
    # weapons behind the character, sliding in from sides
    k1 = eout(t / 0.6); k2 = eout((t - 0.15) / 0.6)
    paste_c(fr, M4_X, W / 2 - 60 - 500 * (1 - k1), 1060, 1.0, clamp(t / 0.3))
    paste_c(fr, P90_X, W / 2 + 60 + 500 * (1 - k2), 1080, 1.0, clamp((t - 0.15) / 0.3))
    cx = W / 2; top = 1920 - PJ_MASK_L.height + 40
    paste_a(fr, PJ_MASK_L, (cx - PJ_MASK_L.width / 2, top + 40 * (1 - eout(t / 0.5)) + 6 * math.sin(T * 2)), clamp(t / 0.3))
    show_text(fr, text_line("Sin complicaciones", 84), t, 260, 0.0)
    show_text(fr, text_line("Sin esperas", 84, CYAN), t, 380, 0.3)
    show_text(fr, text_line("Todo en un solo lugar", 70, GOLD), t, 500, 0.6)
    return fr

def step_scene(img, num, t1, t1c, t2):
    def fn(t, T, d):
        fr = background(T)
        pl = pill(f"PASO {num}", ACC, 44)
        show_text(fr, pl, t, 380, 0.0, dy=25)
        paste_c(fr, img, W / 2, 880 + 12 * math.sin(T * 3), max(0.05, eback((t - 0.1) / 0.45)), clamp((t - 0.1) / 0.15))
        if isinstance(t1, tuple):
            show_text(fr, text_line(t1[0], 88), t, 1290, 0.3)
            show_text(fr, text_line(t1[1], 88, t1c), t, 1400, 0.4)
            show_text(fr, text_line(t2, 48, MUTED, "SemiBold"), t, 1510, 0.55)
        else:
            show_text(fr, text_line(t1, 88, t1c), t, 1320, 0.3)
            show_text(fr, text_line(t2, 48, MUTED, "SemiBold"), t, 1440, 0.5)
        return fr
    return fn

PH_X = (W - PHONE_W) / 2; PH_Y = 420
def sc_phone(t, T, d):
    fr = background(T)
    show_text(fr, text_line("Recarga en segundos", 90), t, 200, 0.0)
    if t < 0.4: lab = None
    elif t < 1.6: lab = "Ingresa el Player ID"
    elif t < 2.3: lab = "Verifica el jugador"
    else: lab = "Elige y confirma"
    if lab:
        pl = pill(lab, ACC, 38); paste_c(fr, pl, W / 2, 320, 1.0, 1.0)
    scr = "a_empty" if t < 1.6 else ("c_verif" if t < 2.3 else "d_sel")
    ph = PHONES[scr]
    if scr == "a_empty" and t > 0.35:
        ph = ph.copy(); dr = ImageDraw.Draw(ph)
        pid = "19470108"; n = int(clamp((t - 0.45) / 0.85) * len(pid) + 1e-4)
        dr.rounded_rectangle([PAD + BEZ + 18 * PS, PAD + BEZ + 208 * PS, PAD + BEZ + 357 * PS, PAD + BEZ + 254 * PS], 9, fill=FIELD)
        dr.text((PAD + BEZ + 33 * PS, PAD + BEZ + 231 * PS), pid[:n], font=F("Regular", round(16 * PS)), fill=(235, 238, 245), anchor="lm")
        if n < len(pid) and int(t * 4) % 2 == 0:
            cxx = PAD + BEZ + 33 * PS + F("Regular", round(16 * PS)).getlength(pid[:n]) + 3
            dr.line([(cxx, PAD + BEZ + 220 * PS), (cxx, PAD + BEZ + 242 * PS)], fill=(235, 238, 245), width=2)
    oy = PH_Y + 100 * (1 - eout(t / 0.35))
    paste_a(fr, ph, (PH_X, oy), clamp(t / 0.2))
    tap_at(fr, *sxy(PH_X, oy, 187, 231), (t - 0.3) / 0.5)
    tap_at(fr, *sxy(PH_X, oy, 187, 303), (t - 1.35) / 0.5)
    if scr == "c_verif" and t > 1.72:
        x0, y0 = sxy(PH_X, oy, 16, 178); x1, y1 = sxy(PH_X, oy, 359, 326)
        ov = Image.new("RGBA", fr.size, (0, 0, 0, 0)); ImageDraw.Draw(ov).rounded_rectangle([x0 - 4, y0 - 4, x1 + 4, y1 + 4], 18, outline=GOLD + (255,), width=6); fr.alpha_composite(ov)
    tap_at(fr, *sxy(PH_X, oy, 98, 570), (t - 2.05) / 0.5)
    tap_at(fr, *sxy(PH_X, oy, 187, 675), (t - 3.2) / 0.5)
    return fr

def sc_ok(t, T, d):
    fr = background(T)
    s = 0.84; ph = scaled(PHONES["e_ok"], s)
    ox = W - ph.width - 10 + 200 * (1 - eout(t / 0.35)); oy = 470
    paste_a(fr, ph, (ox, oy), clamp(t / 0.2))
    left = 15 - 300 * (1 - eout((t - 0.15) / 0.45)); top = 1920 - PJ_YEL_L.height + 20
    paste_a(fr, PJ_YEL_L, (left, top + 6 * math.sin(T * 2.5)), clamp((t - 0.15) / 0.25))
    for k, (txt, col) in enumerate([("Diamantes", WHITE), ("entregados", WHITE), ("al instante", CYAN)]):
        im = text_line(txt, 74, col); p = eback((t - 0.3 - k * 0.12) / 0.38)
        if t - 0.3 - k * 0.12 > 0: paste_a(fr, im, (40 - 60 * (1 - p), 470 + k * 95), clamp((t - 0.3 - k * 0.12) / 0.2))
    st = pill("¡RECARGA EXITOSA!", GREEN, 56)
    paste_c(fr, st, W / 2, 300, max(0.05, eback(t / 0.35)), clamp(t / 0.12))
    return fr

def sc_hist(t, T, d):
    fr = background(T)
    s = 0.74; ph = scaled(PHONES["f_hist"], s)
    ox = W - ph.width - 10 + 200 * (1 - eout(t / 0.4)); oy = 560
    paste_a(fr, ph, (ox, oy), clamp(t / 0.2))
    left = -95 - 300 * (1 - eout((t - 0.15) / 0.45)); top = 1920 - PJ_HOLO_L.height + 60
    paste_a(fr, PJ_HOLO_L, (left, top + 6 * math.sin(T * 2.3)), clamp((t - 0.15) / 0.25))
    show_text(fr, text_line("Controla todos", 88), t, 230, 0.0)
    show_text(fr, text_line("tus pedidos", 88, CYAN), t, 340, 0.2)
    show_text(fr, text_line("Desde tu celular, donde estés", 46, MUTED, "SemiBold"), t, 450, 0.45)
    return fr

def sc_cta(t, T, d):
    fr = background(T, rays=1.1, cy=1030, ray_color=(60, 200, 120))
    paste_c(fr, scaled(LOGO_G, 0.72), W / 2, 330, max(0.05, eback(t / 0.4)), clamp(t / 0.15))
    show_text(fr, text_line("Pide tu cuenta hoy", 92), t, 640, 0.2)
    show_text(fr, text_line("y empieza a vender", 80, GOLD), t, 760, 0.35)
    ps = eback((t - 0.6) / 0.4) * (1 + 0.05 * math.sin(T * 6) * clamp(t - 1.0))
    paste_c(fr, with_glow(WA_L, 50, 26, (60, 220, 110), 0.8) if "WA_G" not in globals() else WA_G, W / 2, 1060, max(0.05, ps), clamp((t - 0.6) / 0.15))
    show_text(fr, text_line("Escríbenos", 70), t, 1290, 0.9)
    paste_a(fr, DISC, ((W - DISC.width) / 2, 1440), clamp((t - 1.1) / 0.4) * 0.9)
    return fr
WA_G = with_glow(WA_L, 50, 26, (60, 220, 110), 0.8)

def make_disc():
    f = F("Medium", 25); lines = ["Free Fire y Garena son marcas registradas de sus propietarios.", "Este sitio no está patrocinado por Garena."]
    w = int(max(f.getlength(l) for l in lines)) + 10; im = Image.new("RGBA", (w, 80), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    for i, l in enumerate(lines): d.text((w / 2, 18 + i * 36), l, font=f, fill=(165, 175, 195), anchor="mm")
    return im
DISC = make_disc()

SCENES = [sc_hook, sc_biz, sc_logo, sc_easy,
          step_scene(MAL_STEP, 1, "Recibe tu cuenta", WHITE, "Te la entrega nuestro soporte"),
          step_scene(COF_STEP, 2, "Abona tu saldo", WHITE, "Cuenta prepago, sin sorpresas"),
          step_scene(DIAMS_STEP, 3, ("Recarga con el", "Player ID"), CYAN, "Y listo, diamantes entregados"),
          sc_phone, sc_ok, sc_hist, sc_cta]

def frame(T):
    i = 0
    while i < len(SCENES) - 1 and T >= BOUNDS[i + 1]: i += 1
    t = T - BOUNDS[i]; d = BOUNDS[i + 1] - BOUNDS[i] if i + 1 < len(BOUNDS) else 3
    fr = SCENES[i](t, T, d)
    if i > 0 and t < 0.14:
        fr.alpha_composite(Image.new("RGBA", fr.size, (255, 255, 255, int(90 * (1 - t / 0.14)))))
    if T > TOTAL - 0.6:
        fr.alpha_composite(Image.new("RGBA", fr.size, (0, 0, 0, int(255 * clamp((T - (TOTAL - 0.6)) / 0.6)))))
    return fr.convert("RGB")

# ---------- sfx: only clicks + typing ----------
EVENTS = []
P0 = BOUNDS[7]
EVENTS.append((P0 + 0.3, "click"))
for j in range(8): EVENTS.append((P0 + 0.45 + (j + 1) * 0.85 / 8 - 0.05, "key"))
EVENTS += [(P0 + 1.35, "click"), (P0 + 2.05, "click"), (P0 + 3.2, "click")]
rng = np.random.default_rng(5)
def envx(n, tau): return np.exp(-np.arange(n) / (tau * SR))
def s_click():
    n = int(.045 * SR); tt = np.arange(n) / SR
    s = np.diff(rng.standard_normal(n + 1)) * envx(n, .0025) * .35 + np.sin(2 * np.pi * 1900 * tt) * envx(n, .006) * .6 + np.sin(2 * np.pi * 220 * tt) * envx(n, .012) * .5
    return .32 * s / np.abs(s).max()
def s_key():
    n = int(.035 * SR); tt = np.arange(n) / SR
    s = np.diff(rng.standard_normal(n + 1)) * envx(n, .0015) * .5 + np.sin(2 * np.pi * rng.uniform(2300, 3300) * tt) * envx(n, .003) * .5 + np.sin(2 * np.pi * 170 * tt) * envx(n, .008) * .6
    return .2 * s / np.abs(s).max()
GEN = {"click": s_click, "key": s_key}
def build_sfx(path):
    buf = np.zeros(int((TOTAL + 1) * SR))
    for t, k in EVENTS:
        s = GEN[k](); i = int(t * SR); buf[i:i + len(s)] += s
    buf = buf[: int(TOTAL * SR)]
    st = (np.stack([buf, buf], 1) * 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(st.tobytes())

if __name__ == "__main__":
    if "--preview" in sys.argv:
        import os; os.makedirs(str(BASE / "preview"), exist_ok=True)
        for i in range(len(SCENES)):
            a, b = BOUNDS[i], BOUNDS[i + 1]
            for fr_ in (0.3, 0.85):
                frame(a + (b - a) * fr_).save(str(BASE / "preview") + f"/p{i:02d}_{int(fr_*100)}.png")
        sys.exit()
    out = sys.argv[1]; vid = str(BASE / "_tmp_video.mp4")
    ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                           "-c:v", "libx264", "-preset", "slow", "-crf", "16", "-tune", "animation", "-pix_fmt", "yuv420p", vid], stdin=subprocess.PIPE)
    n = int(TOTAL * FPS)
    for f in range(n):
        ff.stdin.write(frame(f / FPS).tobytes())
    ff.stdin.close(); ff.wait()
    build_sfx(str(BASE / "_tmp_sfx.wav"))
    fo = TOTAL - 2.8
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", vid, "-i", str(BASE / "_tmp_sfx.wav"), "-ss", str(SONG_START), "-t", str(TOTAL), "-i", SONG,
                    "-filter_complex", f"[2:a]aresample=44100,volume=-12dB,afade=t=in:st=0:d=0.4,afade=t=out:st={fo:.2f}:d=2.8[m];[1:a]volume=3dB[s];[s][m]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95[a]",
                    "-map", "0:v", "-map", "[a]", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", out], check=True)
    print("done", TOTAL, file=sys.stderr)
