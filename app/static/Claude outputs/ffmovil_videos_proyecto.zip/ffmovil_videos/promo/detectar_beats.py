"""Recalcula beats.npy (tiempos de beat de la canción desde SONG_START) para sincronizar los cortes.
Solo hace falta si cambias de canción o de segundo de inicio.  pip install librosa
Uso: python3 detectar_beats.py musica/Killer_Queen.mp3 84.5
"""
import sys, subprocess, numpy as np, librosa
from pathlib import Path
song, start = sys.argv[1], float(sys.argv[2])
wav = Path(__file__).parent / "_tmp_song.wav"
subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", str(start), "-t", "40", "-i", song, "-ac", "1", "-ar", "22050", str(wav)], check=True)
y, sr = librosa.load(str(wav), sr=22050)
tempo, beats = librosa.beat.beat_track(y=y, sr=sr)
bt = librosa.frames_to_time(beats, sr=sr)
np.save(Path(__file__).parent / "beats.npy", bt); wav.unlink()
print("tempo", tempo, "beats", len(bt), np.round(bt[:12], 2))
