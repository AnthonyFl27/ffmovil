# FFMovil – Proyecto de videos (para continuar con otro LLM)

> **Si eres un LLM que retoma este proyecto, lee este archivo entero antes de tocar nada.**
> Todo el video se genera **por código** (Python + Pillow + ffmpeg). No hay editor de video:
> para cambiar algo editas el script, regeneras y entregas el MP4.

FFMovil (ffmovil.com) es una plataforma para **revendedores** de diamantes de Free Fire:
el admin crea la cuenta del revendedor, le abona saldo (prepago) y el revendedor recarga
diamantes a sus clientes con el Player ID.

Hay **dos videos verticales (1080×1920, 30 fps, para TikTok)**:

| Video | Script | Último resultado aprobado |
|---|---|---|
| **Promo** (publicitario, ~27.5 s, al ritmo de la música) | `promo/promo.py` | `videos_finales/promo_v3.mp4` |
| **Tutorial** (explicativo paso a paso, 96 s) | `tutorial/tutorial.py` + `tutorial/mezclar_musica.sh` | `videos_finales/tutorial_v4_musica.mp4` |

---

## 1. Requisitos e instalación

- Python 3.10+ y **ffmpeg / ffprobe** en el PATH.
- `pip install -r requirements.txt` (pillow, numpy; librosa solo si recalculas beats).
- Las fuentes **Inter / Inter Display** ya vienen en `fonts/` (licencia OFL incluida).
  Las rutas de los scripts son **relativas a su carpeta**, no hay que tocar nada.

## 2. Cómo generar

### Promo
```bash
cd promo
python3 promo.py --preview        # 2 fotogramas PNG por escena en promo/preview/ (rápido, ~5 s)
python3 promo.py salida.mp4       # render completo con música y efectos (~2–3 min)
```

### Tutorial
```bash
cd tutorial
python3 tutorial.py --preview                    # JPGs por escena en tutorial/preview/
python3 tutorial.py tutorial_sin_musica.mp4      # video + efectos de sonido (~3 min)
./mezclar_musica.sh tutorial_sin_musica.mp4 tutorial_con_musica.mp4   # añade la canción
```

**Flujo de trabajo recomendado:** cambiar código → `--preview` → revisar los fotogramas
(hacer una hoja de contacto con Pillow ayuda) → recién entonces render completo →
extraer algunos fotogramas del MP4 con ffmpeg para verificar → entregar.

---

## 3. Estructura de carpetas

```
ffmovil_videos/
├── README.md               ← este archivo
├── requirements.txt
├── fonts/                  ← Inter + Inter Display (.otf) y licencia
├── promo/
│   ├── promo.py            ← script del video promocional
│   ├── beats.npy           ← tiempos de beat de la canción (desde el seg. 84.5)
│   ├── detectar_beats.py   ← regenera beats.npy si cambias canción/inicio
│   ├── musica/Killer_Queen.mp3
│   └── assets/
│       ├── web/            ← imágenes ORIGINALES de la web (app/static del proyecto)
│       │   ├── logo.png
│       │   └── inicio/ freefire-blanco, personaje-1/2/3, cofre, maletin, diamantes, arma-1/2 (.webp)
│       ├── extra/          ← imágenes que entregó el cliente (ya recortadas, fondo transparente)
│       │   diamantes, maletin, cofre, pj_mask, pj_holo, pj_yellow, m4, p90, whatsapp (.png)
│       └── capturas/       ← capturas móviles 375×812 de la plataforma, SIN PRECIOS
│           a_empty (recargar vacío), b_id (ID escrito), c_verif (jugador verificado + paquetes),
│           d_sel (paquete elegido + confirmar), e_ok (recarga exitosa), f_hist (historial)
├── tutorial/
│   ├── tutorial.py         ← script del tutorial
│   ├── mezclar_musica.sh   ← mezcla Starman (desde 0:35) de fondo
│   ├── musica/Starman.mp3
│   └── assets/             ← capturas móviles 375×812 (con precios, es tutorial) + logo + personaje
│       h0–h3.jpg (portada en scroll), 04_login … 15_fondos.png, d37ac0cc (cambiar contraseña),
│       c88ed701 (logo), char_key.png (personaje sin fondo), 3586fa4c (personaje original)
├── videos_finales/         ← últimos MP4 aprobados (promo_v3, tutorial_v4_musica, tutorial_v2_sin_musica)
└── referencias/            ← capturas con el feedback del cliente (qué NO repetir)
```

---

## 4. Promo (`promo/promo.py`) – cómo está construido

- **Sincronización con la música:** `BOUNDS` = inicio de cada escena, cada 4 beats
  (`beats.npy`, ~117 BPM). Tiempos actuales (s):
  `0 · 2.25 · 4.30 · 6.32 · 8.34 · 10.40 · 12.52 · 14.58 · 18.78 · 20.85 · 22.83 · 26.96` (+0.6 s de fundido).
- **Escenas (lista `SCENES`, en orden):**

| # | Función | Contenido |
|---|---|---|
| 0 | `sc_hook` | Logo FREE FIRE + “¿Juegas Free Fire?” + diamantes grandes (con rayos de sol) |
| 1 | `sc_biz` | “Conviértelo en tu negocio” + personaje-2 con diamantes flotando sobre su palma |
| 2 | `sc_logo` | Logo FFMovil con onda + “Vende diamantes a tus clientes” (con rayos de sol) |
| 3 | `sc_easy` | “Sin complicaciones / Sin esperas / Todo en un solo lugar” + pj_mask con M4 y P90 en X detrás |
| 4–6 | `step_scene` | PASO 1 maletín “Recibe tu cuenta” · PASO 2 cofre “Abona tu saldo” · PASO 3 diamantes “Recarga con el Player ID” |
| 7 | `sc_phone` | “Recarga en segundos”: celular, se teclea el ID 19470108, verificar, elegir paquete, confirmar (con toques) |
| 8 | `sc_ok` | “¡RECARGA EXITOSA!” + “Diamantes entregados al instante” + pj_yellow + celular con el pedido |
| 9 | `sc_hist` | “Controla todos tus pedidos” + pj_holo + celular con historial |
| 10 | `sc_cta` | Logo + “Pide tu cuenta hoy y empieza a vender” + logo WhatsApp + “Escríbenos” + aviso legal Garena (con rayos de sol) |

- **Utilidades clave:** `text_line()` (texto nítido renderizado a su tamaño real, con sombra suave),
  `show_text()` (aparición: deslizamiento + fundido, sin escalar), `pill()`, `phone_img()`,
  `tap_at()` (círculo de toque), `background(T, rays=...)` (rayos solo si `rays>0`), `with_glow()`.
- **Coordenadas del celular:** las de las capturas son en píxeles 375×812; `sxy()` las convierte.
- **Audio:** `EVENTS` → solo `click` (toques) y `key` (tecleo del ID) en la escena 7.
  Música: Killer Queen desde **84.5 s**, **-12 dB**, efectos **+3 dB**, fade-in 0.4 s, **fade-out 2.8 s** al final.

## 5. Tutorial (`tutorial/tutorial.py`) – resumen

Escenas con decorador `@scene(duración)`, crossfade de 0.35 s entre escenas, celular centrado
(escala 1.95) con título arriba. Orden: intro (logo+personaje) → navegador escribiendo ffmovil.com →
scroll de la portada → tocar “Iniciar sesión” → escribir bowie/bowie123 → aviso “¿Primera vez?” →
cambiar contraseña → panel → menú → **saldo/Fondos (ANTES DE RECARGAR, contactar soporte)** →
PASO 1 Recargar → PASO 2 Player ID → PASO 3 verificar → PASO 4 paquete → PASO 5 confirmar →
recarga exitosa → historial → cierre.
Sonidos (sintetizados en el script): clic, tecleo, whoosh suave en transiciones, deslizamiento, éxito.
Música: `mezclar_musica.sh` (Starman desde 0:35, -11 dB, efectos +6 dB, fade-out 3 s).

---

## 6. Preferencias y decisiones del cliente (RESPETAR)

**Generales**
- Formato vertical TikTok 1080×1920. Mantener lo importante en la **zona segura**:
  nada clave debajo de ~y=1550 (texto de TikTok) ni pegado al borde derecho (íconos de TikTok).
- **No dejar espacios vacíos grandes**; el cliente revisa y marca huecos (ver `referencias/`).
- **No escalar mucho las imágenes** (pierden calidad); recortarlas bien (fondo transparente, sin bordes).
- Personajes bien ubicados: completos/cortados por el borde de forma natural, no tapando texto ni el celular.
- Tipografía nítida (no escalar bitmaps de texto); Inter Display ExtraBold para titulares.

**Promo**
- **Sin precios** en ninguna parte (las capturas se tomaron ocultando montos y saldo con JS).
- Llamada a la acción: **solo el logo de WhatsApp** + “Escríbenos” (sin número).
- Efecto “sol” (rayos giratorios) **solo en algunos slides**: inicio, logo y cierre.
- Sonidos: **solo clics y tecleo**. Nada de whoosh/impactos/transiciones.
- Música de fondo (baja) y que **se difumine al final**.
- Diamantes: usar `assets/extra/diamantes.png` **completo** (no recortar partes, quedaba “raro”).

**Tutorial**
- Básico y explicativo; saldo/Fondos **antes** de recargar (sin saldo no se puede recargar).
- Sin datos de contacto del soporte (“contacta a nuestro soporte”).
- Música de fondo baja para que se escuchen los efectos.

## 7. Plataforma / entorno de pruebas (para nuevas capturas)

- Entorno local de pruebas: `http://localhost:8000` (en la computadora del cliente).
  Usuario de PRUEBA `bowie` / `bowie123` (no es real). Player ID de prueba `19470108` → “Jugador0108”.
- Rutas útiles: `/login`, `/inicio`, `/recargar`, `/historial`, `/fondos`.
- Capturas en viewport móvil **375×812**. La barra naranja “Protected by Cloudflare” de abajo
  se recorta (las capturas se usan hasta y=764).
- Para ocultar precios antes de capturar se ejecutó en la página:
  ```js
  document.querySelectorAll('article.saldo').forEach(e=>e.style.display='none');
  document.querySelectorAll('main *').forEach(e=>{
    if(e.children.length===0 && /USD/.test(e.textContent)) e.style.display='none';
    const t=e.textContent.trim();
    if(/^(Precio|Monto|Saldo disponible)$/.test(t)){e.style.display='none'; if(e.nextElementSibling) e.nextElementSibling.style.display='none';}
  });
  ```
- Código de la web del cliente: `~/Documentos/projects/ffmovil` (imágenes en `app/static/`).

## 8. Historial de versiones (resumen)

- **Tutorial:** v1 → v2 (personaje integrado sin cuadro, celular más grande, slide de saldo antes de
  recargar, sonidos) → v3/v4 (música Starman de fondo; v4 con música y efectos más fuertes). ✅
- **Promo:** v1 (mezcla de 3 conceptos) → v2 (diamantes/personajes/armas nuevos, texto nítido, logo
  WhatsApp, solo clics/tecleo) → v3 (rellenar espacios vacíos, rayos solo en 3 slides). ✅ actual.
